// ссылка openserver
"https://ospanel.io"
// ссылка на firebase
"https://firebase.google.com/?hl=ru"
